# Simple library Managment System Using Django Framework

this is a project of library managment system 
you could run it through django 
##  Installation of Requierements 
```bash

pip install requierement.txt

```
## Running Application
```bash
python manage.py runserver
```
# Thanks
